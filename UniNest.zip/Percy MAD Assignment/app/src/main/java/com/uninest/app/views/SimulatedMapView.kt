package com.uninest.app.views

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.DashPathEffect
import android.graphics.Paint
import android.graphics.Path
import android.util.AttributeSet
import android.view.View

class SimulatedMapView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null,
    defStyleAttr: Int = 0
) : View(context, attrs, defStyleAttr) {

    private var startLocation: String = "Accommodation"
    private var campusName: String = "Campus"
    private var distanceKm: Double = 0.0

    private val gridPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#E5E5EA")
        strokeWidth = 2f
        style = Paint.Style.STROKE
    }

    private val roadPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#D1D1D6")
        strokeWidth = 16f
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
    }

    private val roadCenterLinePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE
        strokeWidth = 2f
        style = Paint.Style.STROKE
        pathEffect = DashPathEffect(floatArrayOf(10f, 10f), 0f)
    }

    private val routePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#FF9500") // Orange route line
        strokeWidth = 10f
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
    }

    private val pinPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.FILL
    }

    private val textPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#1C1C1E")
        textSize = 28f
        style = Paint.Style.FILL
        textAlign = Paint.Align.CENTER
    }

    fun updateRoute(start: String, campus: String, distance: Double) {
        this.startLocation = start
        this.campusName = campus
        this.distanceKm = distance
        invalidate()
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val w = width.toFloat()
        val h = height.toFloat()

        // Draw soft grid lines for map feel
        val gridSize = 60f
        var x = 0f
        while (x < w) {
            canvas.drawLine(x, 0f, x, h, gridPaint)
            x += gridSize
        }
        var y = 0f
        while (y < h) {
            canvas.drawLine(0f, y, w, y, gridPaint)
            y += gridSize
        }

        // Draw Simulated Roads
        val roadPath = Path()
        // Horizontal main road (Tlokweng Rd / Mobuto Dr)
        roadPath.moveTo(40f, h * 0.5f)
        roadPath.lineTo(w - 40f, h * 0.5f)
        
        // Vertical connecting roads
        roadPath.moveTo(w * 0.25f, 40f)
        roadPath.lineTo(w * 0.25f, h - 40f)

        roadPath.moveTo(w * 0.75f, 40f)
        roadPath.lineTo(w * 0.75f, h - 40f)

        canvas.drawPath(roadPath, roadPaint)
        canvas.drawPath(roadPath, roadCenterLinePaint)

        // Draw Route (Start Pin to Campus Pin)
        val routePath = Path()
        
        // Adjust start coordinates based on area
        val startX = w * 0.25f
        val startY = h * 0.25f
        
        // Adjust destination coordinates based on campus
        val endX = w * 0.75f
        val endY = h * 0.75f

        // Draw route lines connecting them
        routePath.moveTo(startX, startY)
        routePath.lineTo(startX, h * 0.5f)
        routePath.lineTo(endX, h * 0.5f)
        routePath.lineTo(endX, endY)
        canvas.drawPath(routePath, routePaint)

        // Draw Start Location Pin (Blue)
        pinPaint.color = Color.parseColor("#007AFF")
        canvas.drawCircle(startX, startY, 20f, pinPaint)
        pinPaint.color = Color.WHITE
        canvas.drawCircle(startX, startY, 8f, pinPaint)
        canvas.drawText(startLocation, startX, startY - 30f, textPaint)

        // Draw Destination Pin (Red)
        pinPaint.color = Color.parseColor("#FF3B30")
        canvas.drawCircle(endX, endY, 20f, pinPaint)
        pinPaint.color = Color.WHITE
        canvas.drawCircle(endX, endY, 8f, pinPaint)
        canvas.drawText(campusName, endX, endY + 45f, textPaint)
        
        // Draw distance badge inside map
        if (distanceKm > 0.0) {
            val badgeText = String.format("%.1f km", distanceKm)
            val badgePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                color = Color.parseColor("#90000000")
            }
            canvas.drawRect(w * 0.45f - 70f, h * 0.5f - 40f, w * 0.45f + 70f, h * 0.5f + 20f, badgePaint)
            
            val badgeTextPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                color = Color.WHITE
                textSize = 24f
                textAlign = Paint.Align.CENTER
                style = Paint.Style.FILL
            }
            canvas.drawText(badgeText, w * 0.45f, h * 0.5f - 5f, badgeTextPaint)
        }
    }
}
