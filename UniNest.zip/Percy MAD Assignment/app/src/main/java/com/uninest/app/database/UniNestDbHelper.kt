package com.uninest.app.database

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import com.uninest.app.models.Student
import com.uninest.app.models.Listing
import com.uninest.app.models.Booking
import com.uninest.app.models.SearchPreference
import com.uninest.app.models.SmartAlert
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class UniNestDbHelper(context: Context) : SQLiteOpenHelper(context, DATABASE_NAME, null, DATABASE_VERSION) {

    companion object {
        private const val DATABASE_NAME = "UniNest.db"
        private const val DATABASE_VERSION = 1

        // Table Names
        private const val TABLE_STUDENTS = "students"
        private const val TABLE_LISTINGS = "listings"
        private const val TABLE_BOOKINGS = "bookings"
        private const val TABLE_PREFERENCES = "preferences"
        private const val TABLE_ALERTS = "alerts"

        // Common Column Names
        private const val KEY_ID = "id"

        // Students Table Columns
        private const val KEY_STUDENT_USERNAME = "username"
        private const val KEY_STUDENT_NAME = "name"
        private const val KEY_STUDENT_ROLE = "role"
        private const val KEY_STUDENT_EMAIL = "email"
        private const val KEY_STUDENT_PHONE = "phone"

        // Listings Table Columns
        private const val KEY_LISTING_TITLE = "title"
        private const val KEY_LISTING_PRICE = "price"
        private const val KEY_LISTING_LOCATION = "location"
        private const val KEY_LISTING_TYPE = "type"
        private const val KEY_LISTING_AMENITIES = "amenities"
        private const val KEY_LISTING_AVAILABILITY = "availability_date"
        private const val KEY_LISTING_DEPOSIT = "deposit_amount"
        private const val KEY_LISTING_IMAGE = "image_url"
        private const val KEY_LISTING_STATUS = "status"
        private const val KEY_LISTING_DIST_BAC = "distance_bac"
        private const val KEY_LISTING_DIST_UB = "distance_ub"
        private const val KEY_LISTING_DIST_BOTHO = "distance_botho"

        // Bookings Table Columns
        private const val KEY_BOOKING_STUDENT_ID = "student_id"
        private const val KEY_BOOKING_LISTING_ID = "listing_id"
        private const val KEY_BOOKING_REF_NUM = "reference_number"
        private const val KEY_BOOKING_DEPOSIT_PAID = "deposit_paid"
        private const val KEY_BOOKING_DATE = "booking_date"

        // Preferences Table Columns
        private const val KEY_PREF_STUDENT_ID = "student_id"
        private const val KEY_PREF_MAX_PRICE = "max_price"
        private const val KEY_PREF_LOCATION = "location"
        private const val KEY_PREF_AVAILABILITY = "availability_date"

        // Alerts Table Columns
        private const val KEY_ALERT_STUDENT_ID = "student_id"
        private const val KEY_ALERT_LISTING_ID = "listing_id"
        private const val KEY_ALERT_MESSAGE = "message"
        private const val KEY_ALERT_IS_READ = "is_read"
        private const val KEY_ALERT_CREATED_AT = "created_at"
    }

    override fun onCreate(db: SQLiteDatabase) {
        // Create Students Table
        val createStudentsTable = ("CREATE TABLE " + TABLE_STUDENTS + "("
                + KEY_ID + " INTEGER PRIMARY KEY AUTOINCREMENT,"
                + KEY_STUDENT_USERNAME + " TEXT UNIQUE,"
                + KEY_STUDENT_NAME + " TEXT,"
                + KEY_STUDENT_ROLE + " TEXT,"
                + KEY_STUDENT_EMAIL + " TEXT,"
                + KEY_STUDENT_PHONE + " TEXT" + ")")
        db.execSQL(createStudentsTable)

        // Create Listings Table
        val createListingsTable = ("CREATE TABLE " + TABLE_LISTINGS + "("
                + KEY_ID + " INTEGER PRIMARY KEY AUTOINCREMENT,"
                + KEY_LISTING_TITLE + " TEXT,"
                + KEY_LISTING_PRICE + " REAL,"
                + KEY_LISTING_LOCATION + " TEXT,"
                + KEY_LISTING_TYPE + " TEXT,"
                + KEY_LISTING_AMENITIES + " TEXT,"
                + KEY_LISTING_AVAILABILITY + " TEXT,"
                + KEY_LISTING_DEPOSIT + " REAL,"
                + KEY_LISTING_IMAGE + " TEXT,"
                + KEY_LISTING_STATUS + " TEXT,"
                + KEY_LISTING_DIST_BAC + " REAL,"
                + KEY_LISTING_DIST_UB + " REAL,"
                + KEY_LISTING_DIST_BOTHO + " REAL" + ")")
        db.execSQL(createListingsTable)

        // Create Bookings Table
        val createBookingsTable = ("CREATE TABLE " + TABLE_BOOKINGS + "("
                + KEY_ID + " INTEGER PRIMARY KEY AUTOINCREMENT,"
                + KEY_BOOKING_STUDENT_ID + " INTEGER,"
                + KEY_BOOKING_LISTING_ID + " INTEGER,"
                + KEY_BOOKING_REF_NUM + " TEXT UNIQUE,"
                + KEY_BOOKING_DEPOSIT_PAID + " REAL,"
                + KEY_BOOKING_DATE + " TEXT" + ")")
        db.execSQL(createBookingsTable)

        // Create Preferences Table
        val createPreferencesTable = ("CREATE TABLE " + TABLE_PREFERENCES + "("
                + KEY_ID + " INTEGER PRIMARY KEY AUTOINCREMENT,"
                + KEY_PREF_STUDENT_ID + " INTEGER UNIQUE,"
                + KEY_PREF_MAX_PRICE + " REAL,"
                + KEY_PREF_LOCATION + " TEXT,"
                + KEY_PREF_AVAILABILITY + " TEXT" + ")")
        db.execSQL(createPreferencesTable)

        // Create Alerts Table
        val createAlertsTable = ("CREATE TABLE " + TABLE_ALERTS + "("
                + KEY_ID + " INTEGER PRIMARY KEY AUTOINCREMENT,"
                + KEY_ALERT_STUDENT_ID + " INTEGER,"
                + KEY_ALERT_LISTING_ID + " INTEGER,"
                + KEY_ALERT_MESSAGE + " TEXT,"
                + KEY_ALERT_IS_READ + " INTEGER DEFAULT 0,"
                + KEY_ALERT_CREATED_AT + " TEXT" + ")")
        db.execSQL(createAlertsTable)

        // Seed Data
        seedStudents(db)
        seedListings(db)
    }

    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_STUDENTS)
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_LISTINGS)
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_BOOKINGS)
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_PREFERENCES)
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_ALERTS)
        onCreate(db)
    }

    private fun seedStudents(db: SQLiteDatabase) {
        val firstNames = listOf(
            "Thabo", "Kabelo", "Lesedi", "Goitse", "Amantle", "Neo", "Lerato", "Refilwe", "Palesa", "Tshepo",
            "Katlego", "Onkabetse", "Botho", "Kgotla", "Phenyo", "Kelebogile", "Bokang", "Mpho", "Oaitse", "Kagiso",
            "Dumi", "Karabo", "Dineo", "Khumo", "One", "Gorata", "Laone", "Gofaone", "Boipelo", "Koketso",
            "Tefo", "Shanti", "Thato", "Atamelang", "Lorato", "Segomotso", "Wame", "Same", "Gothata", "Lone",
            "Lebogang", "Kaone", "Nonofo", "Tumelo", "Teto", "Omphemetse", "Pelotshweu", "Tsaone", "Aobakwe", "Bosa"
        )
        val lastNames = listOf(
            "Molefe", "Sebego", "Ntuane", "Motsamai", "Phiri", "Lekone", "Kgosi", "Mmereki", "Letsholo", "Dube",
            "Ramosako", "Modise", "Gare", "Morake", "Moagi", "Tshabalala", "Nkgwang", "Matthews", "Setsiba", "Kelepile",
            "Pule", "Tau", "Nkomo", "Masisi", "Kedikilwe", "Phumaphi", "Moitoi", "Balopi", "Molefhabangwe", "Radibe",
            "Seretse", "Sebele", "Tshane", "Rantao", "Sebutle", "Molopo", "Mmopi", "Setso", "Monageng", "Moyo",
            "Nkwe", "Pelo", "Kebalepile", "Marope", "Mpedi", "Gaseitsiwe", "Kabo", "Kwena", "Mokgosi", "Bosa"
        )

        // Seed 50 students
        for (i in 1..50) {
            val name = "${firstNames[i - 1]} ${lastNames[i - 1]}"
            val username = "student$i"
            val email = "${username}@student.ac.bw"
            val phone = "+267 7" + (1000000 + i * 14325).toString()

            val values = ContentValues()
            values.put(KEY_STUDENT_USERNAME, username)
            values.put(KEY_STUDENT_NAME, name)
            values.put(KEY_STUDENT_ROLE, "Student")
            values.put(KEY_STUDENT_EMAIL, email)
            values.put(KEY_STUDENT_PHONE, phone)

            db.insert(TABLE_STUDENTS, null, values)
        }

        // Add user-specific custom student
        val specialValues = ContentValues().apply {
            put(KEY_STUDENT_USERNAME, "ookeditse")
            put(KEY_STUDENT_NAME, "Ookeditse Moekhwa")
            put(KEY_STUDENT_ROLE, "Student")
            put(KEY_STUDENT_EMAIL, "ookeditse@student.bac.ac.bw")
            put(KEY_STUDENT_PHONE, "+267 76543210")
        }
        db.insert(TABLE_STUDENTS, null, specialValues)
    }

    private fun seedListings(db: SQLiteDatabase) {
        val areas = listOf(
            "Block 7", "Block 9", "Phase 2", "Broadhurst", "Tlokweng", 
            "Gaborone West", "Phakalane", "Tsholofelo", "Village", "Block 3"
        )
        val roomTypes = listOf(
            "Single Room", "Bedsitter", "Shared Apartment", "1-Bedroom Flat", "Garden Cottage"
        )
        val amenitiesList = listOf(
            "Wi-Fi, Water Included, Security",
            "Wi-Fi, AC, Parking, Electricity Included",
            "Water Included, Fenced Yard, Parking",
            "Wi-Fi, Fenced, Shared Kitchen",
            "AC, Parking, High Security, Study Desk"
        )
        val sampleImages = listOf(
            "https://images.unsplash.com/photo-1522771739844-6a9f6d5f14af?w=500", // Modern Room 1
            "https://images.unsplash.com/photo-1598928506311-c55ded91a20c?w=500", // Cozy Room 2
            "https://images.unsplash.com/photo-1505691938895-1758d7feb511?w=500", // Simple Room 3
            "https://images.unsplash.com/photo-1586023492125-27b2c045efd7?w=500", // Studio 4
            "https://images.unsplash.com/photo-1560448204-e02f11c3d0e2?w=500"  // Apartment 5
        )

        val dates = listOf(
            "01 Jun 2026", "15 Jun 2026", "01 Jul 2026", "15 Jul 2026", "01 Aug 2026", "15 Aug 2026"
        )

        // Seed 50 listings
        for (i in 1..50) {
            val area = areas[(i - 1) % areas.size]
            val type = roomTypes[(i - 1) % roomTypes.size]
            val amenities = amenitiesList[(i - 1) % amenitiesList.size]
            val image = sampleImages[(i - 1) % sampleImages.size]
            val dateStr = dates[(i - 1) % dates.size]

            // Calculate price: pricing logic based on area and room type
            val basePrice = when(type) {
                "Single Room" -> 900.0
                "Shared Apartment" -> 1200.0
                "Bedsitter" -> 1600.0
                "1-Bedroom Flat" -> 2200.0
                "Garden Cottage" -> 2800.0
                else -> 1500.0
            }
            val areaPremium = when(area) {
                "Phakalane" -> 600.0
                "Block 9" -> 300.0
                "Village" -> 400.0
                "Broadhurst" -> 200.0
                "Tlokweng" -> 0.0
                else -> 100.0
            }
            val price = basePrice + areaPremium + (i % 5) * 50.0
            val deposit = price // Simulated deposit equivalent to 1 month rent

            // Title
            val title = when (i % 3) {
                0 -> "Modern $type in $area"
                1 -> "Cozy Student $type near Campus"
                else -> "Affordable $type in $area"
            }

            // Distances (UB is Village, BAC is Fairgrounds, Botho is GIFP)
            val distUB = when(area) {
                "Village" -> 0.5 + (i % 5) * 0.2
                "Broadhurst" -> 3.5 + (i % 5) * 0.3
                "Tlokweng" -> 2.5 + (i % 5) * 0.4
                "Phase 2" -> 5.5 + (i % 5) * 0.2
                "Gaborone West" -> 4.5 + (i % 5) * 0.3
                "Block 7" -> 7.5 + (i % 5) * 0.4
                "Block 9" -> 8.5 + (i % 5) * 0.2
                "Block 3" -> 6.0 + (i % 5) * 0.3
                "Tsholofelo" -> 4.0 + (i % 5) * 0.5
                else -> 11.0 + (i % 5) * 0.5 // Phakalane
            }

            val distBAC = when(area) {
                "Village" -> 2.2 + (i % 5) * 0.2
                "Broadhurst" -> 5.0 + (i % 5) * 0.3
                "Tlokweng" -> 4.0 + (i % 5) * 0.4
                "Phase 2" -> 4.2 + (i % 5) * 0.2
                "Gaborone West" -> 4.8 + (i % 5) * 0.3
                "Block 7" -> 8.2 + (i % 5) * 0.4
                "Block 9" -> 9.0 + (i % 5) * 0.2
                "Block 3" -> 7.5 + (i % 5) * 0.3
                "Tsholofelo" -> 6.0 + (i % 5) * 0.5
                else -> 13.5 + (i % 5) * 0.5 // Phakalane
            }

            val distBotho = when(area) {
                "Phase 2" -> 1.0 + (i % 5) * 0.1
                "Gaborone West" -> 2.0 + (i % 5) * 0.2
                "Block 9" -> 4.0 + (i % 5) * 0.3
                "Block 7" -> 5.5 + (i % 5) * 0.4
                "Block 3" -> 4.5 + (i % 5) * 0.2
                "Village" -> 6.5 + (i % 5) * 0.3
                "Tlokweng" -> 8.5 + (i % 5) * 0.4
                "Broadhurst" -> 8.0 + (i % 5) * 0.3
                "Tsholofelo" -> 7.5 + (i % 5) * 0.2
                else -> 15.0 + (i % 5) * 0.5 // Phakalane
            }

            val values = ContentValues().apply {
                put(KEY_LISTING_TITLE, title)
                put(KEY_LISTING_PRICE, price)
                put(KEY_LISTING_LOCATION, area)
                put(KEY_LISTING_TYPE, type)
                put(KEY_LISTING_AMENITIES, amenities)
                put(KEY_LISTING_AVAILABILITY, dateStr)
                put(KEY_LISTING_DEPOSIT, deposit)
                put(KEY_LISTING_IMAGE, image)
                put(KEY_LISTING_STATUS, "Available")
                put(KEY_LISTING_DIST_BAC, distBAC)
                put(KEY_LISTING_DIST_UB, distUB)
                put(KEY_LISTING_DIST_BOTHO, distBotho)
            }

            db.insert(TABLE_LISTINGS, null, values)
        }
    }

    // Helper functions for User Authentication
    fun registerStudent(username: String, name: String, email: String, phone: String): Boolean {
        val db = this.writableDatabase
        val values = ContentValues().apply {
            put(KEY_STUDENT_USERNAME, username)
            put(KEY_STUDENT_NAME, name)
            put(KEY_STUDENT_ROLE, "Student")
            put(KEY_STUDENT_EMAIL, email)
            put(KEY_STUDENT_PHONE, phone)
        }
        val result = db.insert(TABLE_STUDENTS, null, values)
        return result != -1L
    }

    fun getStudentByUsername(username: String): Student? {
        val db = this.readableDatabase
        val cursor = db.query(
            TABLE_STUDENTS,
            null,
            "$KEY_STUDENT_USERNAME = ?",
            arrayOf(username),
            null, null, null
        )

        var student: Student? = null
        if (cursor != null && cursor.moveToFirst()) {
            val id = cursor.getInt(cursor.getColumnIndexOrThrow(KEY_ID))
            val name = cursor.getString(cursor.getColumnIndexOrThrow(KEY_STUDENT_NAME))
            val role = cursor.getString(cursor.getColumnIndexOrThrow(KEY_STUDENT_ROLE))
            val email = cursor.getString(cursor.getColumnIndexOrThrow(KEY_STUDENT_EMAIL))
            val phone = cursor.getString(cursor.getColumnIndexOrThrow(KEY_STUDENT_PHONE))
            student = Student(id, username, name, role, email, phone)
            cursor.close()
        }
        return student
    }

    fun getAllStudents(): List<Student> {
        val list = ArrayList<Student>()
        val db = this.readableDatabase
        val cursor = db.rawQuery("SELECT * FROM $TABLE_STUDENTS ORDER BY $KEY_STUDENT_NAME ASC", null)
        if (cursor.moveToFirst()) {
            do {
                val id = cursor.getInt(cursor.getColumnIndexOrThrow(KEY_ID))
                val username = cursor.getString(cursor.getColumnIndexOrThrow(KEY_STUDENT_USERNAME))
                val name = cursor.getString(cursor.getColumnIndexOrThrow(KEY_STUDENT_NAME))
                val role = cursor.getString(cursor.getColumnIndexOrThrow(KEY_STUDENT_ROLE))
                val email = cursor.getString(cursor.getColumnIndexOrThrow(KEY_STUDENT_EMAIL))
                val phone = cursor.getString(cursor.getColumnIndexOrThrow(KEY_STUDENT_PHONE))
                list.add(Student(id, username, name, role, email, phone))
            } while (cursor.moveToNext())
        }
        cursor.close()
        return list
    }

    // Helper functions for Listings
    fun getAllListings(): List<Listing> {
        val list = ArrayList<Listing>()
        val db = this.readableDatabase
        val cursor = db.rawQuery("SELECT * FROM $TABLE_LISTINGS ORDER BY $KEY_ID DESC", null)
        if (cursor.moveToFirst()) {
            do {
                list.add(getListingFromCursor(cursor))
            } while (cursor.moveToNext())
        }
        cursor.close()
        return list
    }

    fun getListingById(id: Int): Listing? {
        val db = this.readableDatabase
        val cursor = db.query(TABLE_LISTINGS, null, "$KEY_ID = ?", arrayOf(id.toString()), null, null, null)
        var listing: Listing? = null
        if (cursor != null && cursor.moveToFirst()) {
            listing = getListingFromCursor(cursor)
            cursor.close()
        }
        return listing
    }

    fun searchListings(query: String?, maxPrice: Double?, location: String?, dateStr: String?): List<Listing> {
        val db = this.readableDatabase
        val selectionArgs = ArrayList<String>()
        var selectionClause = "1=1"

        if (!query.isNullOrBlank()) {
            selectionClause += " AND ($KEY_LISTING_TITLE LIKE ? OR $KEY_LISTING_LOCATION LIKE ? OR $KEY_LISTING_TYPE LIKE ?)"
            selectionArgs.add("%$query%")
            selectionArgs.add("%$query%")
            selectionArgs.add("%$query%")
        }

        if (maxPrice != null && maxPrice > 0) {
            selectionClause += " AND $KEY_LISTING_PRICE <= ?"
            selectionArgs.add(maxPrice.toString())
        }

        if (!location.isNullOrBlank() && location != "All") {
            selectionClause += " AND $KEY_LISTING_LOCATION = ?"
            selectionArgs.add(location)
        }

        if (!dateStr.isNullOrBlank() && dateStr != "Any") {
            // Note: Simplistic text-based matching or date parsing
            selectionClause += " AND $KEY_LISTING_AVAILABILITY LIKE ?"
            selectionArgs.add("%$dateStr%")
        }

        val cursor = db.query(
            TABLE_LISTINGS,
            null,
            selectionClause,
            selectionArgs.toTypedArray(),
            null, null, "$KEY_ID DESC"
        )

        val list = ArrayList<Listing>()
        if (cursor.moveToFirst()) {
            do {
                list.add(getListingFromCursor(cursor))
            } while (cursor.moveToNext())
        }
        cursor.close()
        return list
    }

    private fun getListingFromCursor(cursor: android.database.Cursor): Listing {
        val id = cursor.getInt(cursor.getColumnIndexOrThrow(KEY_ID))
        val title = cursor.getString(cursor.getColumnIndexOrThrow(KEY_LISTING_TITLE))
        val price = cursor.getDouble(cursor.getColumnIndexOrThrow(KEY_LISTING_PRICE))
        val location = cursor.getString(cursor.getColumnIndexOrThrow(KEY_LISTING_LOCATION))
        val type = cursor.getString(cursor.getColumnIndexOrThrow(KEY_LISTING_TYPE))
        val amenities = cursor.getString(cursor.getColumnIndexOrThrow(KEY_LISTING_AMENITIES))
        val availability = cursor.getString(cursor.getColumnIndexOrThrow(KEY_LISTING_AVAILABILITY))
        val deposit = cursor.getDouble(cursor.getColumnIndexOrThrow(KEY_LISTING_DEPOSIT))
        val image = cursor.getString(cursor.getColumnIndexOrThrow(KEY_LISTING_IMAGE))
        val status = cursor.getString(cursor.getColumnIndexOrThrow(KEY_LISTING_STATUS))
        val distBAC = cursor.getDouble(cursor.getColumnIndexOrThrow(KEY_LISTING_DIST_BAC))
        val distUB = cursor.getDouble(cursor.getColumnIndexOrThrow(KEY_LISTING_DIST_UB))
        val distBotho = cursor.getDouble(cursor.getColumnIndexOrThrow(KEY_LISTING_DIST_BOTHO))
        return Listing(id, title, price, location, type, amenities, availability, deposit, image, status, distBAC, distUB, distBotho)
    }

    // Bookings / Deposit simulated processing
    fun reserveRoom(studentId: Int, listingId: Int, depositAmount: Double): Booking? {
        val db = this.writableDatabase
        db.beginTransaction()
        try {
            // Check status first
            val cursor = db.query(TABLE_LISTINGS, arrayOf(KEY_LISTING_STATUS), "$KEY_ID = ?", arrayOf(listingId.toString()), null, null, null)
            var currentStatus = ""
            if (cursor != null && cursor.moveToFirst()) {
                currentStatus = cursor.getString(cursor.getColumnIndexOrThrow(KEY_LISTING_STATUS))
                cursor.close()
            }

            if (currentStatus == "Reserved") {
                return null // Already reserved by another user
            }

            // Generate receipt reference number e.g. UN-2026-XXXX
            val randomRefNum = "UN-2026-" + (100000 + (Math.random() * 900000).toInt()).toString()
            val bookingDate = SimpleDateFormat("dd MMM yyyy HH:mm", Locale.getDefault()).format(Date())

            val bookingValues = ContentValues().apply {
                put(KEY_BOOKING_STUDENT_ID, studentId)
                put(KEY_BOOKING_LISTING_ID, listingId)
                put(KEY_BOOKING_REF_NUM, randomRefNum)
                put(KEY_BOOKING_DEPOSIT_PAID, depositAmount)
                put(KEY_BOOKING_DATE, bookingDate)
            }

            val bookingId = db.insert(TABLE_BOOKINGS, null, bookingValues)

            if (bookingId != -1L) {
                // Update listing status
                val updateValues = ContentValues().apply {
                    put(KEY_LISTING_STATUS, "Reserved")
                }
                db.update(TABLE_LISTINGS, updateValues, "$KEY_ID = ?", arrayOf(listingId.toString()))
                db.setTransactionSuccessful()
                
                return Booking(bookingId.toInt(), studentId, listingId, randomRefNum, depositAmount, bookingDate)
            }
        } catch (e: Exception) {
            e.printStackTrace()
        } finally {
            db.endTransaction()
        }
        return null
    }

    fun getStudentBookings(studentId: Int): List<Booking> {
        val list = ArrayList<Booking>()
        val db = this.readableDatabase
        val cursor = db.query(TABLE_BOOKINGS, null, "$KEY_BOOKING_STUDENT_ID = ?", arrayOf(studentId.toString()), null, null, "$KEY_ID DESC")
        if (cursor.moveToFirst()) {
            do {
                val id = cursor.getInt(cursor.getColumnIndexOrThrow(KEY_ID))
                val listingId = cursor.getInt(cursor.getColumnIndexOrThrow(KEY_BOOKING_LISTING_ID))
                val refNum = cursor.getString(cursor.getColumnIndexOrThrow(KEY_BOOKING_REF_NUM))
                val deposit = cursor.getDouble(cursor.getColumnIndexOrThrow(KEY_BOOKING_DEPOSIT_PAID))
                val date = cursor.getString(cursor.getColumnIndexOrThrow(KEY_BOOKING_DATE))
                list.add(Booking(id, studentId, listingId, refNum, deposit, date))
            } while (cursor.moveToNext())
        }
        cursor.close()
        return list
    }

    // Preferences & Smart Alerts Engine
    fun saveSearchPreference(studentId: Int, maxPrice: Double, location: String, availabilityDate: String): Boolean {
        val db = this.writableDatabase
        val values = ContentValues().apply {
            put(KEY_PREF_STUDENT_ID, studentId)
            put(KEY_PREF_MAX_PRICE, maxPrice)
            put(KEY_PREF_LOCATION, location)
            put(KEY_PREF_AVAILABILITY, availabilityDate)
        }
        // Use REPLACE to overwrite existing preference for this student
        val result = db.replace(TABLE_PREFERENCES, null, values)
        
        // Trigger alerts engine! Check if any available rooms match this preference and write alerts
        if (result != -1L) {
            checkAndGenerateAlerts(studentId, maxPrice, location, availabilityDate)
        }
        return result != -1L
    }

    fun getSearchPreference(studentId: Int): SearchPreference? {
        val db = this.readableDatabase
        val cursor = db.query(TABLE_PREFERENCES, null, "$KEY_PREF_STUDENT_ID = ?", arrayOf(studentId.toString()), null, null, null)
        var pref: SearchPreference? = null
        if (cursor != null && cursor.moveToFirst()) {
            val id = cursor.getInt(cursor.getColumnIndexOrThrow(KEY_ID))
            val maxPrice = cursor.getDouble(cursor.getColumnIndexOrThrow(KEY_PREF_MAX_PRICE))
            val location = cursor.getString(cursor.getColumnIndexOrThrow(KEY_PREF_LOCATION))
            val date = cursor.getString(cursor.getColumnIndexOrThrow(KEY_PREF_AVAILABILITY))
            pref = SearchPreference(id, studentId, maxPrice, location, date)
            cursor.close()
        }
        return pref
    }

    private fun checkAndGenerateAlerts(studentId: Int, maxPrice: Double, location: String, date: String) {
        val db = this.writableDatabase
        // Match listings
        var queryStr = "SELECT * FROM $TABLE_LISTINGS WHERE $KEY_LISTING_STATUS = 'Available' AND $KEY_LISTING_PRICE <= ?"
        val args = ArrayList<String>()
        args.add(maxPrice.toString())

        if (location != "All") {
            queryStr += " AND $KEY_LISTING_LOCATION = ?"
            args.add(location)
        }
        
        if (date != "Any") {
            queryStr += " AND $KEY_LISTING_AVAILABILITY LIKE ?"
            args.add("%$date%")
        }

        val cursor = db.rawQuery(queryStr, args.toTypedArray())
        if (cursor.moveToFirst()) {
            do {
                val listingId = cursor.getInt(cursor.getColumnIndexOrThrow(KEY_ID))
                val title = cursor.getString(cursor.getColumnIndexOrThrow(KEY_LISTING_TITLE))
                val price = cursor.getDouble(cursor.getColumnIndexOrThrow(KEY_LISTING_PRICE))
                val loc = cursor.getString(cursor.getColumnIndexOrThrow(KEY_LISTING_LOCATION))
                
                // Construct alert message
                val message = "Smart Alert Match: $title is available in $loc for BWP $price!"
                val createdAt = SimpleDateFormat("dd MMM yyyy HH:mm", Locale.getDefault()).format(Date())

                // Check if alert already exists for this listing and student
                val alertCheckCursor = db.query(
                    TABLE_ALERTS, 
                    arrayOf(KEY_ID), 
                    "$KEY_ALERT_STUDENT_ID = ? AND $KEY_ALERT_LISTING_ID = ?", 
                    arrayOf(studentId.toString(), listingId.toString()), 
                    null, null, null
                )
                val exists = alertCheckCursor != null && alertCheckCursor.count > 0
                alertCheckCursor?.close()

                if (!exists) {
                    val alertValues = ContentValues().apply {
                        put(KEY_ALERT_STUDENT_ID, studentId)
                        put(KEY_ALERT_LISTING_ID, listingId)
                        put(KEY_ALERT_MESSAGE, message)
                        put(KEY_ALERT_IS_READ, 0)
                        put(KEY_ALERT_CREATED_AT, createdAt)
                    }
                    db.insert(TABLE_ALERTS, null, alertValues)
                }
            } while (cursor.moveToNext())
        }
        cursor.close()
    }

    fun getStudentAlerts(studentId: Int): List<SmartAlert> {
        val list = ArrayList<SmartAlert>()
        val db = this.readableDatabase
        val cursor = db.query(TABLE_ALERTS, null, "$KEY_ALERT_STUDENT_ID = ?", arrayOf(studentId.toString()), null, null, "$KEY_ID DESC")
        if (cursor.moveToFirst()) {
            do {
                val id = cursor.getInt(cursor.getColumnIndexOrThrow(KEY_ID))
                val listingId = cursor.getInt(cursor.getColumnIndexOrThrow(KEY_ALERT_LISTING_ID))
                val msg = cursor.getString(cursor.getColumnIndexOrThrow(KEY_ALERT_MESSAGE))
                val isRead = cursor.getInt(cursor.getColumnIndexOrThrow(KEY_ALERT_IS_READ))
                val date = cursor.getString(cursor.getColumnIndexOrThrow(KEY_ALERT_CREATED_AT))
                list.add(SmartAlert(id, studentId, listingId, msg, isRead, date))
            } while (cursor.moveToNext())
        }
        cursor.close()
        return list
    }

    fun markAlertsAsRead(studentId: Int) {
        val db = this.writableDatabase
        val values = ContentValues().apply {
            put(KEY_ALERT_IS_READ, 1)
        }
        db.update(TABLE_ALERTS, values, "$KEY_ALERT_STUDENT_ID = ?", arrayOf(studentId.toString()))
    }
}
