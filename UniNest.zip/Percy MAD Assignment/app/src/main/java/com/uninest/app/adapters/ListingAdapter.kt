package com.uninest.app.adapters

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.uninest.app.R
import com.uninest.app.databinding.ItemListingRecommendedBinding
import com.uninest.app.models.Listing

class ListingAdapter(
    private var listings: List<Listing>,
    private val onItemClick: (Listing) -> Unit
) : RecyclerView.Adapter<ListingAdapter.ViewHolder>() {

    class ViewHolder(val binding: ItemListingRecommendedBinding) : RecyclerView.ViewHolder(binding.root)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val binding = ItemListingRecommendedBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return ViewHolder(binding)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val listing = listings[position]
        val binding = holder.binding
        val context = holder.itemView.context

        binding.tvRoomTitle.text = listing.title
        binding.tvRoomPrice.text = "BWP ${String.format("%,.0f", listing.price)}/month"
        binding.tvRoomLocation.text = "Gaborone, ${listing.location}"
        binding.tvRoomDistance.text = "BAC: ${listing.distanceBAC}km | UB: ${listing.distanceUB}km | Botho: ${listing.distanceBotho}km"
        binding.tvRoomAvailability.text = "Avail: ${listing.availabilityDate}"

        // Load image using Glide
        Glide.with(context)
            .load(listing.imageUrl)
            .placeholder(R.drawable.ic_room_placeholder)
            .error(R.drawable.ic_room_placeholder)
            .into(binding.ivRoomImage)

        // Bind Reserved/Available status badge
        if (listing.status == "Reserved") {
            binding.tvStatusBadge.text = "Reserved"
            binding.tvStatusBadge.setTextColor(ContextCompat.getColor(context, R.color.accent))
            binding.tvStatusBadge.setBackgroundResource(R.drawable.bg_badge_reserved)
        } else {
            binding.tvStatusBadge.text = "Available"
            binding.tvStatusBadge.setTextColor(ContextCompat.getColor(context, R.color.success))
            binding.tvStatusBadge.setBackgroundResource(R.drawable.bg_badge_available)
        }

        // Wishlist mock
        var isFav = false
        binding.ivFavorite.setOnClickListener {
            isFav = !isFav
            if (isFav) {
                binding.ivFavorite.setImageResource(R.drawable.ic_favorite)
                binding.ivFavorite.setColorFilter(ContextCompat.getColor(context, R.color.accent))
            } else {
                binding.ivFavorite.setImageResource(R.drawable.ic_favorite_border)
                binding.ivFavorite.setColorFilter(ContextCompat.getColor(context, R.color.text_secondary))
            }
        }

        holder.itemView.setOnClickListener {
            onItemClick(listing)
        }
    }

    override fun getItemCount(): Int = listings.size

    fun updateData(newList: List<Listing>) {
        listings = newList
        notifyDataSetChanged()
    }
}
