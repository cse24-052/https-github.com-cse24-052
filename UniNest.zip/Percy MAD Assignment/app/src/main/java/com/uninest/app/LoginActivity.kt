package com.uninest.app

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.uninest.app.database.UniNestDbHelper
import com.uninest.app.databinding.ActivityLoginBinding

class LoginActivity : AppCompatActivity() {

    private lateinit var binding: ActivityLoginBinding
    private lateinit var dbHelper: UniNestDbHelper
    private var isLoginTab = true

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityLoginBinding.inflate(layoutInflater)
        setContentView(binding.root)

        dbHelper = UniNestDbHelper(this)

        setupTabs()
        setupStudentSpinner()
        setupAuthActions()
    }

    private fun setupTabs() {
        binding.tabLogin.setOnClickListener {
            if (!isLoginTab) {
                isLoginTab = true
                binding.tabLogin.setBackgroundTintList(getColorStateList(R.color.primary))
                binding.tabLogin.setTextColor(getColor(R.color.text_on_primary))
                binding.tabRegister.setBackgroundColor(android.graphics.Color.TRANSPARENT)
                binding.tabRegister.setTextColor(getColor(R.color.text_primary))
                
                binding.loginFormLayout.visibility = View.VISIBLE
                binding.registerFormLayout.visibility = View.GONE
            }
        }

        binding.tabRegister.setOnClickListener {
            if (isLoginTab) {
                isLoginTab = false
                binding.tabRegister.setBackgroundTintList(getColorStateList(R.color.primary))
                binding.tabRegister.setTextColor(getColor(R.color.text_on_primary))
                binding.tabLogin.setBackgroundColor(android.graphics.Color.TRANSPARENT)
                binding.tabLogin.setTextColor(getColor(R.color.text_primary))
                
                binding.registerFormLayout.visibility = View.VISIBLE
                binding.loginFormLayout.visibility = View.GONE
            }
        }
    }

    private fun setupStudentSpinner() {
        val students = dbHelper.getAllStudents()
        val displayNames = ArrayList<String>()
        displayNames.add("Select a Student Account...")
        
        for (student in students) {
            displayNames.add("${student.name} (${student.username})")
        }

        val adapter = ArrayAdapter(this, android.R.layout.simple_spinner_item, displayNames)
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        binding.studentSpinner.adapter = adapter

        binding.studentSpinner.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) {
                if (position > 0) {
                    val selectedStudent = students[position - 1]
                    binding.etLoginUsername.setText(selectedStudent.username)
                }
            }

            override fun onNothingSelected(parent: AdapterView<*>?) {}
        }
    }

    private fun setupAuthActions() {
        binding.btnLogin.setOnClickListener {
            val username = binding.etLoginUsername.text.toString().trim()
            if (username.isEmpty()) {
                Toast.makeText(this, "Please enter a username", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            val student = dbHelper.getStudentByUsername(username)
            if (student != null) {
                // Successful login
                val intent = Intent(this, MainActivity::class.java).apply {
                    putExtra("username", student.username)
                    putExtra("name", student.name)
                    putExtra("student_id", student.id)
                }
                startActivity(intent)
                finish()
            } else {
                Toast.makeText(this, "Username not found. Try student1 to student50", Toast.LENGTH_LONG).show()
            }
        }

        binding.btnRegister.setOnClickListener {
            val name = binding.etRegName.text.toString().trim()
            val username = binding.etRegUsername.text.toString().trim().lowercase()
            val email = binding.etRegEmail.text.toString().trim()
            val phone = binding.etRegPhone.text.toString().trim()

            if (name.isEmpty() || username.isEmpty() || email.isEmpty() || phone.isEmpty()) {
                Toast.makeText(this, "Please fill in all fields", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            // Check if username already exists
            val existing = dbHelper.getStudentByUsername(username)
            if (existing != null) {
                Toast.makeText(this, "Username is already taken", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            val success = dbHelper.registerStudent(username, name, email, phone)
            if (success) {
                Toast.makeText(this, "Registration Successful!", Toast.LENGTH_SHORT).show()
                val newStudent = dbHelper.getStudentByUsername(username)
                if (newStudent != null) {
                    val intent = Intent(this, MainActivity::class.java).apply {
                        putExtra("username", newStudent.username)
                        putExtra("name", newStudent.name)
                        putExtra("student_id", newStudent.id)
                    }
                    startActivity(intent)
                    finish()
                }
            } else {
                Toast.makeText(this, "Registration Failed. Try again", Toast.LENGTH_SHORT).show()
            }
        }
    }
}
