package com.uninest.app.fragments

import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import android.os.Build
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ArrayAdapter
import android.widget.Toast
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.LinearLayoutManager
import com.uninest.app.MainActivity
import com.uninest.app.R
import com.uninest.app.adapters.AlertAdapter
import com.uninest.app.database.UniNestDbHelper
import com.uninest.app.databinding.FragmentAlertsBinding
import com.uninest.app.models.SmartAlert

class AlertsFragment : Fragment() {

    private var _binding: FragmentAlertsBinding? = null
    private val binding get() = _binding!!

    private lateinit var dbHelper: UniNestDbHelper
    private lateinit var adapter: AlertAdapter
    
    private val CHANNEL_ID = "uninest_alerts_channel"
    private val NOTIFICATION_ID = 1001

    private val areas = arrayOf(
        "All", "Block 7", "Block 9", "Phase 2", "Broadhurst", "Tlokweng", 
        "Gaborone West", "Phakalane", "Tsholofelo", "Village", "Block 3"
    )

    private val dates = arrayOf(
        "Any", "01 Jun 2026", "15 Jun 2026", "01 Jul 2026", "15 Jul 2026", "01 Aug 2026", "15 Aug 2026"
    )

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentAlertsBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        dbHelper = UniNestDbHelper(requireContext())
        createNotificationChannel()

        setupSpinners()
        setupRecyclerView()
        loadPreferencesAndAlerts()

        binding.btnSavePreferences.setOnClickListener {
            savePreferences()
        }
    }

    private fun setupSpinners() {
        val areaAdapter = ArrayAdapter(requireContext(), android.R.layout.simple_spinner_item, areas)
        areaAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        binding.spinnerPrefLocation.adapter = areaAdapter

        val dateAdapter = ArrayAdapter(requireContext(), android.R.layout.simple_spinner_item, dates)
        dateAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        binding.spinnerPrefDate.adapter = dateAdapter
    }

    private fun setupRecyclerView() {
        binding.rvAlerts.layoutManager = LinearLayoutManager(context)
        adapter = AlertAdapter(ArrayList()) { listingId ->
            (activity as? MainActivity)?.navigateToExplore(listingId)
        }
        binding.rvAlerts.adapter = adapter
    }

    private fun loadPreferencesAndAlerts() {
        val activity = activity as? MainActivity ?: return
        val studentId = activity.studentId

        // Load saved preferences
        val pref = dbHelper.getSearchPreference(studentId)
        if (pref != null) {
            binding.etPrefPrice.setText(pref.maxPrice.toString())
            
            val areaPos = areas.indexOf(pref.location)
            if (areaPos != -1) binding.spinnerPrefLocation.setSelection(areaPos)

            val datePos = dates.indexOf(pref.availabilityDate)
            if (datePos != -1) binding.spinnerPrefDate.setSelection(datePos)
        }

        // Load alerts list
        refreshAlertsList()
    }

    private fun refreshAlertsList() {
        val activity = activity as? MainActivity ?: return
        val studentId = activity.studentId
        val alerts = dbHelper.getStudentAlerts(studentId)

        if (alerts.isEmpty()) {
            binding.tvEmptyAlerts.visibility = View.VISIBLE
            binding.rvAlerts.visibility = View.GONE
        } else {
            binding.tvEmptyAlerts.visibility = View.GONE
            binding.rvAlerts.visibility = View.VISIBLE
            adapter.updateData(alerts)
        }

        // Mark alerts as read upon viewing
        if (alerts.any { it.isRead == 0 }) {
            dbHelper.markAlertsAsRead(studentId)
        }
    }

    private fun savePreferences() {
        val activity = activity as? MainActivity ?: return
        val studentId = activity.studentId

        val priceStr = binding.etPrefPrice.text.toString().trim()
        if (priceStr.isEmpty()) {
            Toast.makeText(context, "Please enter a maximum price budget", Toast.LENGTH_SHORT).show()
            return
        }

        val maxPrice = priceStr.toDoubleOrNull()
        if (maxPrice == null || maxPrice <= 0) {
            Toast.makeText(context, "Please enter a valid price budget", Toast.LENGTH_SHORT).show()
            return
        }

        val location = binding.spinnerPrefLocation.selectedItem.toString()
        val availabilityDate = binding.spinnerPrefDate.selectedItem.toString()

        // Get count of alerts before saving preferences to check if new alerts are generated
        val initialAlerts = dbHelper.getStudentAlerts(studentId)

        val success = dbHelper.saveSearchPreference(studentId, maxPrice, location, availabilityDate)
        if (success) {
            Toast.makeText(context, "Preferences saved & alert check complete!", Toast.LENGTH_SHORT).show()
            
            // Reload alerts from db
            val updatedAlerts = dbHelper.getStudentAlerts(studentId)
            
            // If the updated alert count is higher than before, trigger a local notification
            val newAlertsCount = updatedAlerts.size - initialAlerts.size
            if (newAlertsCount > 0) {
                val latestAlert = updatedAlerts.first()
                triggerLocalNotification(latestAlert.message)
            } else {
                Toast.makeText(context, "No new matching listings found for this preference. Adjust filters!", Toast.LENGTH_LONG).show()
            }
            
            refreshAlertsList()
        } else {
            Toast.makeText(context, "Failed to save preferences", Toast.LENGTH_SHORT).show()
        }
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val name = "UniNest Match Alerts"
            val descriptionText = "Channel for UniNest student accommodation match alerts"
            val importance = NotificationManager.IMPORTANCE_HIGH
            val channel = NotificationChannel(CHANNEL_ID, name, importance).apply {
                description = descriptionText
            }
            val notificationManager: NotificationManager =
                requireContext().getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            notificationManager.createNotificationChannel(channel)
        }
    }

    private fun triggerLocalNotification(message: String) {
        val builder = NotificationCompat.Builder(requireContext(), CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_notification_badge)
            .setContentTitle("UniNest Match Found! 🏠")
            .setContentText(message)
            .setStyle(NotificationCompat.BigTextStyle().bigText(message))
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setAutoCancel(true)

        val notificationManager = NotificationManagerCompat.from(requireContext())
        try {
            notificationManager.notify(NOTIFICATION_ID, builder.build())
        } catch (e: SecurityException) {
            // Under Android 13+, this permission error might catch, fallback to a Toast
            Toast.makeText(context, "Alert Match: $message", Toast.LENGTH_LONG).show()
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
