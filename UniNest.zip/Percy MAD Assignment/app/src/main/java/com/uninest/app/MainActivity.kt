package com.uninest.app

import android.content.Intent
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.fragment.app.Fragment
import com.uninest.app.database.UniNestDbHelper
import com.uninest.app.databinding.ActivityMainBinding
import com.uninest.app.fragments.AlertsFragment
import com.uninest.app.fragments.BookingsFragment
import com.uninest.app.fragments.ExploreFragment
import com.uninest.app.fragments.HomeFragment
import com.uninest.app.fragments.ProfileFragment

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    
    var studentId: Int = 0
    var studentUsername: String = ""
    var studentName: String = ""
    
    lateinit var dbHelper: UniNestDbHelper

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        dbHelper = UniNestDbHelper(this)

        // Read student details passed from LoginActivity
        studentId = intent.getIntExtra("student_id", 0)
        studentUsername = intent.getStringExtra("username") ?: ""
        studentName = intent.getStringExtra("name") ?: ""

        if (studentId == 0) {
            // Default fallback if session data is missing
            val defaultStudent = dbHelper.getStudentByUsername("ookeditse")
            if (defaultStudent != null) {
                studentId = defaultStudent.id
                studentUsername = defaultStudent.username
                studentName = defaultStudent.name
            }
        }

        setupBottomNavigation()
        
        // Show HomeFragment by default, or navigate directly to Explore map / Bookings if intent specifies
        val navigateToExploreId = intent.getIntExtra("navigate_to_explore_listing_id", -1)
        val navigateToBookings = intent.getBooleanExtra("navigate_to_bookings", false)
        if (navigateToExploreId != -1) {
            navigateToExplore(navigateToExploreId)
        } else if (navigateToBookings) {
            navigateToBookings()
        } else if (savedInstanceState == null) {
            loadFragment(HomeFragment())
        }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        val navigateToExploreId = intent.getIntExtra("navigate_to_explore_listing_id", -1)
        val navigateToBookings = intent.getBooleanExtra("navigate_to_bookings", false)
        if (navigateToExploreId != -1) {
            navigateToExplore(navigateToExploreId)
        } else if (navigateToBookings) {
            navigateToBookings()
        }
    }

    private fun setupBottomNavigation() {
        binding.navView.setOnItemSelectedListener { item ->
            val fragment: Fragment = when (item.itemId) {
                R.id.navigation_home -> HomeFragment()
                R.id.navigation_explore -> ExploreFragment()
                R.id.navigation_bookings -> BookingsFragment()
                R.id.navigation_alerts -> AlertsFragment()
                R.id.navigation_profile -> ProfileFragment()
                else -> HomeFragment()
            }
            loadFragment(fragment)
            true
        }
    }

    fun loadFragment(fragment: Fragment) {
        supportFragmentManager.beginTransaction()
            .replace(R.id.fragment_container, fragment)
            .commit()
    }

    // Programmatic routing helpers
    fun navigateToExplore(listingId: Int) {
        val exploreFragment = ExploreFragment.newInstance(listingId)
        binding.navView.selectedItemId = R.id.navigation_explore
        loadFragment(exploreFragment)
    }

    fun navigateToBookings() {
        binding.navView.selectedItemId = R.id.navigation_bookings
        loadFragment(BookingsFragment())
    }

    fun switchLoggedStudent(newStudentId: Int, username: String, name: String) {
        this.studentId = newStudentId
        this.studentUsername = username
        this.studentName = name
        // Reload current fragment to update UI greetings/data
        val currentFrag = supportFragmentManager.findFragmentById(R.id.fragment_container)
        if (currentFrag != null) {
            loadFragment(currentFrag::class.java.newInstance())
        }
    }
}
