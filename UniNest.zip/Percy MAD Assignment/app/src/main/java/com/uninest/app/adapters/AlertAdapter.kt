package com.uninest.app.adapters

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.uninest.app.databinding.ItemAlertBinding
import com.uninest.app.models.SmartAlert

class AlertAdapter(
    private var alerts: List<SmartAlert>,
    private val onViewClick: (Int) -> Unit
) : RecyclerView.Adapter<AlertAdapter.ViewHolder>() {

    class ViewHolder(val binding: ItemAlertBinding) : RecyclerView.ViewHolder(binding.root)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val binding = ItemAlertBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return ViewHolder(binding)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val alert = alerts[position]
        val binding = holder.binding

        binding.tvAlertMessage.text = alert.message
        binding.tvAlertDate.text = alert.createdAt

        // Show/hide red indicator dot based on unread status
        if (alert.isRead == 1) {
            binding.viewAlertIndicator.visibility = View.INVISIBLE
        } else {
            binding.viewAlertIndicator.visibility = View.VISIBLE
        }

        binding.btnViewAlertDeal.setOnClickListener {
            onViewClick(alert.listingId)
        }
    }

    override fun getItemCount(): Int = alerts.size

    fun updateData(newList: List<SmartAlert>) {
        alerts = newList
        notifyDataSetChanged()
    }
}
