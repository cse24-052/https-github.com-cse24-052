package com.uninest.app.fragments

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.AdapterView
import android.widget.ArrayAdapter
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.LinearLayoutManager
import com.uninest.app.MainActivity
import com.uninest.app.adapters.ListingAdapter
import com.uninest.app.database.UniNestDbHelper
import com.uninest.app.ListingDetailActivity
import com.uninest.app.databinding.FragmentExploreBinding
import com.uninest.app.models.Listing

class ExploreFragment : Fragment() {

    private var _binding: FragmentExploreBinding? = null
    private val binding get() = _binding!!

    private lateinit var dbHelper: UniNestDbHelper
    private lateinit var adapter: ListingAdapter
    private var allListings = ArrayList<Listing>()
    
    private var selectedCampus = "BAC" // "BAC", "UB", "Botho"
    private var focusedListingId: Int = -1

    companion object {
        private const val ARG_LISTING_ID = "focused_listing_id"

        fun newInstance(listingId: Int): ExploreFragment {
            val fragment = ExploreFragment()
            val args = Bundle()
            args.putInt(ARG_LISTING_ID, listingId)
            fragment.arguments = args
            return fragment
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        arguments?.let {
            focusedListingId = it.getInt(ARG_LISTING_ID, -1)
        }
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentExploreBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        dbHelper = UniNestDbHelper(requireContext())
        allListings.addAll(dbHelper.getAllListings())

        setupCampusSpinner()
        setupRecyclerView()
        
        // Initial sorting
        sortListingsAndRefresh()

        // Handle focused listing passed from other screens
        if (focusedListingId != -1) {
            val listing = allListings.find { it.id == focusedListingId }
            if (listing != null) {
                focusOnListing(listing)
            }
        }

        binding.cardDirections.setOnClickListener {
            if (focusedListingId != -1) {
                val intent = android.content.Intent(context, ListingDetailActivity::class.java).apply {
                    putExtra("listing_id", focusedListingId)
                    val mainAct = activity as? MainActivity
                    putExtra("student_id", mainAct?.studentId ?: 0)
                }
                startActivity(intent)
            }
        }
    }

    private fun setupCampusSpinner() {
        val campuses = arrayOf(
            "Botswana Accountancy College (BAC)",
            "University of Botswana (UB)",
            "Botho University"
        )
        val spinnerAdapter = ArrayAdapter(requireContext(), android.R.layout.simple_spinner_item, campuses)
        spinnerAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        binding.campusSpinner.adapter = spinnerAdapter

        binding.campusSpinner.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) {
                selectedCampus = when (position) {
                    0 -> "BAC"
                    1 -> "UB"
                    2 -> "Botho"
                    else -> "BAC"
                }
                sortListingsAndRefresh()
            }

            override fun onNothingSelected(parent: AdapterView<*>?) {}
        }
    }

    private fun setupRecyclerView() {
        adapter = ListingAdapter(ArrayList()) { listing ->
            focusOnListing(listing)
        }
        binding.rvExploreListings.layoutManager = LinearLayoutManager(context)
        binding.rvExploreListings.adapter = adapter
    }

    private fun sortListingsAndRefresh() {
        // Sort listings by distance to selected campus
        val sorted = when (selectedCampus) {
            "BAC" -> allListings.sortedBy { it.distanceBAC }
            "UB" -> allListings.sortedBy { it.distanceUB }
            "Botho" -> allListings.sortedBy { it.distanceBotho }
            else -> allListings
        }

        adapter.updateData(sorted)

        // Select the closest available listing as default visual map route
        if (focusedListingId == -1 && sorted.isNotEmpty()) {
            focusOnListing(sorted.first())
        }
    }

    private fun focusOnListing(listing: Listing) {
        focusedListingId = listing.id
        val distance = when (selectedCampus) {
            "BAC" -> listing.distanceBAC
            "UB" -> listing.distanceUB
            "Botho" -> listing.distanceBotho
            else -> 0.0
        }

        val fullCampusName = when (selectedCampus) {
            "BAC" -> "BAC Fairgrounds"
            "UB" -> "UB Village Campus"
            "Botho" -> "Botho GIFP Campus"
            else -> "Campus"
        }

        // Update Map View Canvas Route
        binding.simulatedMapView.updateRoute(listing.location, selectedCampus, distance)
        binding.tvMapOverlayDistance.text = "${listing.location} to $selectedCampus (${String.format("%.1f", distance)} km)"

        // Update Text Steps Info
        binding.tvDirectionsTitle.text = "Directions: ${listing.title} to $fullCampusName"
        binding.tvDirectionsSteps.text = getRouteSteps(listing.location, selectedCampus, distance)
    }

    private fun getRouteSteps(location: String, campus: String, distance: Double): String {
        val campusName = when (campus) {
            "BAC" -> "BAC Campus (Fairgrounds)"
            "UB" -> "UB Main Campus (Village)"
            "Botho" -> "Botho Campus (Gaborone International Finance Park)"
            else -> "Campus"
        }

        val combiRoutes = when(location) {
            "Phakalane" -> "Board Phakalane Route 1 combi to Station, change to Route 4/5 combi to Fairgrounds/UB."
            "Block 7" -> "Board Route 3 combi to Station, switch to Route 4 (BAC) or UB bus."
            "Block 9" -> "Board Route 8 combi to Station, switch to Route 4 (BAC) or UB bus."
            "Broadhurst" -> "Board Broadhurst Route 2 combi directly to UB or switch at Station for BAC."
            "Tlokweng" -> "Board Tlokweng Route 1 combi directly passing UB / Fairgrounds."
            "Village" -> "Walking distance (~10-15 mins walk) or direct short combi route."
            else -> "Board local area combi to Station, then connect to the campus shuttle combi."
        }

        return "1. Exit accommodation in $location.\n" +
                "2. Walk 200m to the nearest combi/bus transit stop.\n" +
                "3. $combiRoutes\n" +
                "4. Disembark at $campusName.\n" +
                "Total Distance: ${String.format("%.1f", distance)} km\n" +
                "Estimated transit time: ~${(distance * 3.5).toInt() + 10} minutes"
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
