package com.uninest.app

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.bumptech.glide.Glide
import com.uninest.app.database.UniNestDbHelper
import com.uninest.app.databinding.ActivityListingDetailBinding
import com.uninest.app.models.Listing

class ListingDetailActivity : AppCompatActivity() {

    private lateinit var binding: ActivityListingDetailBinding
    private lateinit var dbHelper: UniNestDbHelper
    private var listingId: Int = -1
    private var listing: Listing? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityListingDetailBinding.inflate(layoutInflater)
        setContentView(binding.root)

        dbHelper = UniNestDbHelper(this)
        listingId = intent.getIntExtra("listing_id", -1)

        if (listingId == -1) {
            Toast.makeText(this, "Invalid Listing ID", Toast.LENGTH_SHORT).show()
            finish()
            return
        }

        loadListingDetails()
        setupListeners()
    }

    override fun onResume() {
        super.onResume()
        // Re-load listing details in case status was updated during reservation
        loadListingDetails()
    }

    private fun loadListingDetails() {
        listing = dbHelper.getListingById(listingId)
        val currentListing = listing

        if (currentListing == null) {
            Toast.makeText(this, "Error loading accommodation details", Toast.LENGTH_SHORT).show()
            finish()
            return
        }

        // Load image using Glide
        Glide.with(this)
            .load(currentListing.imageUrl)
            .placeholder(R.drawable.ic_room_placeholder)
            .error(R.drawable.ic_room_placeholder)
            .into(binding.ivDetailRoomImage)

        // Title and Location
        binding.tvDetailTitle.text = currentListing.title
        binding.tvDetailLocation.text = "Gaborone Area, ${currentListing.location}"

        // Price and Type
        binding.tvDetailPrice.text = "BWP ${String.format("%,.2f", currentListing.price)}"
        binding.tvDetailType.text = currentListing.type

        // Campus Distances
        binding.tvDistBAC.text = "${String.format("%.1f", currentListing.distanceBAC)} km"
        binding.tvDistUB.text = "${String.format("%.1f", currentListing.distanceUB)} km"
        binding.tvDistBotho.text = "${String.format("%.1f", currentListing.distanceBotho)} km"

        // Amenities and Availability Date
        binding.tvDetailAmenities.text = currentListing.amenities
        binding.tvDetailAvailabilityDate.text = currentListing.availabilityDate

        // Deposit amount bottom label
        binding.tvDetailDepositPrice.text = "BWP ${String.format("%,.2f", currentListing.depositAmount)}"

        // Status configuration and reservation lock logic
        if (currentListing.status == "Reserved") {
            binding.tvDetailStatus.text = "Reserved"
            binding.tvDetailStatus.setBackgroundResource(R.drawable.bg_badge_reserved)
            binding.tvDetailStatus.setTextColor(getColor(R.color.accent)) // Badge Text Red
            
            // Disable booking actions
            binding.btnReserve.isEnabled = false
            binding.btnReserve.text = "Locked - Reserved"
            binding.btnReserve.setBackgroundColor(getColor(R.color.text_hint))
        } else {
            binding.tvDetailStatus.text = "Available"
            binding.tvDetailStatus.setBackgroundResource(R.drawable.bg_badge_available)
            binding.tvDetailStatus.setTextColor(getColor(R.color.success)) // Badge Text Green
            
            // Enable booking actions
            binding.btnReserve.isEnabled = true
            binding.btnReserve.text = "Pay Deposit & Reserve"
            binding.btnReserve.setBackgroundColor(getColor(R.color.primary))
        }
    }

    private fun setupListeners() {
        // Back navigation
        binding.btnBack.setOnClickListener {
            finish()
        }

        // Route redirection to MainActivity map view
        binding.btnViewOnMap.setOnClickListener {
            val intent = Intent(this, MainActivity::class.java).apply {
                putExtra("navigate_to_explore_listing_id", listingId)
                flags = Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP
            }
            startActivity(intent)
            finish()
        }

        // Reservation launch
        binding.btnReserve.setOnClickListener {
            val currentListing = listing ?: return@setOnClickListener
            
            // Re-verify availability double book lock from DB first
            val freshListing = dbHelper.getListingById(listingId)
            if (freshListing?.status == "Reserved") {
                Toast.makeText(this, "Sorry, this room was just reserved by another student!", Toast.LENGTH_LONG).show()
                loadListingDetails()
                return@setOnClickListener
            }

            // Launch payment activity
            val intent = Intent(this, PaymentActivity::class.java).apply {
                putExtra("listing_id", listingId)
                putExtra("student_id", this@ListingDetailActivity.intent.getIntExtra("student_id", 0))
                putExtra("deposit_amount", currentListing.depositAmount)
                putExtra("room_title", currentListing.title)
                putExtra("room_location", currentListing.location)
            }
            startActivity(intent)
        }
    }
}
