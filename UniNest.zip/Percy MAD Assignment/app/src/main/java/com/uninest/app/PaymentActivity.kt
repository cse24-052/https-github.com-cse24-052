package com.uninest.app

import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.text.Editable
import android.text.TextWatcher
import android.view.View
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.uninest.app.database.UniNestDbHelper
import com.uninest.app.databinding.ActivityPaymentBinding

class PaymentActivity : AppCompatActivity() {

    private lateinit var binding: ActivityPaymentBinding
    private lateinit var dbHelper: UniNestDbHelper

    private var listingId: Int = -1
    private var studentId: Int = 0
    private var depositAmount: Double = 0.0
    private var roomTitle: String = ""
    private var roomLocation: String = ""

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityPaymentBinding.inflate(layoutInflater)
        setContentView(binding.root)

        dbHelper = UniNestDbHelper(this)

        // Read intent extras
        listingId = intent.getIntExtra("listing_id", -1)
        studentId = intent.getIntExtra("student_id", 0)
        depositAmount = intent.getDoubleExtra("deposit_amount", 0.0)
        roomTitle = intent.getStringExtra("room_title") ?: "Accommodation Room"
        roomLocation = intent.getStringExtra("room_location") ?: "Gaborone"

        if (listingId == -1 || studentId == 0) {
            Toast.makeText(this, "Session expired or invalid listing data", Toast.LENGTH_SHORT).show()
            finish()
            return
        }

        setupSummaryCard()
        setupListeners()
        setupCardNumberFormatting()
    }

    private fun setupSummaryCard() {
        binding.tvPaymentRoomTitle.text = roomTitle
        binding.tvPaymentRoomLoc.text = "Gaborone, $roomLocation"
        binding.tvPaymentAmount.text = "BWP ${String.format("%,.2f", depositAmount)}"
    }

    private fun setupListeners() {
        // Back navigation
        binding.btnPaymentBack.setOnClickListener {
            finish()
        }

        // Submit Payment Click
        binding.btnSubmitPayment.setOnClickListener {
            if (validateCardInputs()) {
                startSimulatedPayment()
            }
        }
    }

    // Custom text formatting for credit card: inserts space after every 4 digits
    private fun setupCardNumberFormatting() {
        binding.etCardNumber.addTextChangedListener(object : TextWatcher {
            private var isUpdating = false
            private val space = ' '

            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}

            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}

            override fun afterTextChanged(s: Editable?) {
                if (isUpdating) return
                isUpdating = true

                // Remove all spaces
                val originalString = s.toString().replace(space.toString(), "")
                val formattedStringBuilder = StringBuilder()

                for (i in originalString.indices) {
                    formattedStringBuilder.append(originalString[i])
                    if ((i + 1) % 4 == 0 && i + 1 < originalString.length) {
                        formattedStringBuilder.append(space)
                    }
                }

                s?.replace(0, s.length, formattedStringBuilder.toString())
                isUpdating = false
            }
        })

        // Auto format Expiry date MM/YY (add slash after 2 digits)
        binding.etCardExpiry.addTextChangedListener(object : TextWatcher {
            private var isUpdating = false
            
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}

            override fun afterTextChanged(s: Editable?) {
                if (isUpdating) return
                isUpdating = true

                val original = s.toString().replace("/", "")
                if (original.length >= 2) {
                    val formatted = original.substring(0, 2) + "/" + original.substring(2)
                    s?.replace(0, s.length, formatted)
                }
                
                isUpdating = false
            }
        })
    }

    private fun validateCardInputs(): Boolean {
        val name = binding.etCardName.text.toString().trim()
        val rawCard = binding.etCardNumber.text.toString().replace(" ", "").trim()
        val expiry = binding.etCardExpiry.text.toString().trim()
        val cvv = binding.etCardCVV.text.toString().trim()

        if (name.isEmpty()) {
            binding.etCardName.error = "Cardholder name is required"
            return false
        }

        if (rawCard.length != 16 || !rawCard.all { it.isDigit() }) {
            binding.etCardNumber.error = "Valid 16-digit card number is required"
            return false
        }

        if (expiry.length != 5 || !expiry.contains("/") || expiry.indexOf('/') != 2) {
            binding.etCardExpiry.error = "Expiry date must be in MM/YY format"
            return false
        }

        val monthStr = expiry.split("/").firstOrNull() ?: ""
        val monthVal = monthStr.toIntOrNull()
        if (monthVal == null || monthVal < 1 || monthVal > 12) {
            binding.etCardExpiry.error = "Invalid expiry month"
            return false
        }

        if (cvv.length != 3 || !cvv.all { it.isDigit() }) {
            binding.etCardCVV.error = "3-digit CVV code is required"
            return false
        }

        return true
    }

    private fun startSimulatedPayment() {
        // Hide keyboard / forms & show loading state overlay
        binding.paymentFormScrollView.visibility = View.GONE
        binding.paymentLoadingLayout.visibility = View.VISIBLE

        // Simulate 2 seconds banking API lag
        Handler(Looper.getMainLooper()).postDelayed({
            processDatabaseBooking()
        }, 2000)
    }

    private fun processDatabaseBooking() {
        // Reserve room in SQL database (handles transactional status lock to Reserved)
        val booking = dbHelper.reserveRoom(studentId, listingId, depositAmount)

        if (booking != null) {
            // Success view population
            binding.tvReceiptRef.text = booking.referenceNumber
            binding.tvReceiptAmount.text = "BWP ${String.format("%,.2f", booking.depositPaid)}"
            binding.tvReceiptRoom.text = roomTitle

            // Toggle screens
            binding.paymentLoadingLayout.visibility = View.GONE
            binding.paymentSuccessLayout.visibility = View.VISIBLE

            // Close actions: Navigate back to MainActivity focusing on the Bookings Tab
            binding.btnReceiptDone.setOnClickListener {
                val intent = Intent(this, MainActivity::class.java).apply {
                    putExtra("navigate_to_bookings", true)
                    flags = Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP
                }
                startActivity(intent)
                finish()
            }
        } else {
            // Failed due to double booking or exception (lock failed)
            binding.paymentLoadingLayout.visibility = View.GONE
            binding.paymentFormScrollView.visibility = View.VISIBLE
            Toast.makeText(this, "Simulated payment failed. This room was just reserved by another student!", Toast.LENGTH_LONG).show()
        }
    }
}
