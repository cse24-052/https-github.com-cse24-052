package com.uninest.app.adapters

import android.app.Dialog
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.view.LayoutInflater
import android.view.ViewGroup
import android.view.Window
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.uninest.app.MainActivity
import com.uninest.app.R
import com.uninest.app.database.UniNestDbHelper
import com.uninest.app.databinding.ItemBookingBinding
import com.uninest.app.models.Booking

class BookingAdapter(
    private var bookings: List<Booking>,
    private val dbHelper: UniNestDbHelper
) : RecyclerView.Adapter<BookingAdapter.ViewHolder>() {

    class ViewHolder(val binding: ItemBookingBinding) : RecyclerView.ViewHolder(binding.root)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val binding = ItemBookingBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return ViewHolder(binding)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val booking = bookings[position]
        val binding = holder.binding
        val context = holder.itemView.context

        // Look up listing details from db
        val listing = dbHelper.getListingById(booking.listingId)
        if (listing != null) {
            binding.tvBookingRoomTitle.text = listing.title
            binding.tvBookingLocation.text = "Gaborone, ${listing.location}"

            Glide.with(context)
                .load(listing.imageUrl)
                .placeholder(R.drawable.ic_room_placeholder)
                .error(R.drawable.ic_room_placeholder)
                .into(binding.ivBookingRoomImage)

            // Setup navigation click
            binding.btnViewRoute.setOnClickListener {
                if (context is MainActivity) {
                    context.navigateToExplore(listing.id)
                }
            }
        } else {
            binding.tvBookingRoomTitle.text = "Room ID: ${booking.listingId}"
            binding.tvBookingLocation.text = "Location details unavailable"
        }

        binding.tvBookingRefNum.text = booking.referenceNumber
        binding.tvBookingDepositPaid.text = "BWP ${String.format("%,.2f", booking.depositPaid)}"
        binding.tvBookingDate.text = booking.bookingDate

        // Setup Receipt Modal View Click
        binding.btnViewReceipt.setOnClickListener {
            showReceiptDialog(context, booking, listing?.title ?: "Accommodation Room")
        }
    }

    override fun getItemCount(): Int = bookings.size

    fun updateData(newList: List<Booking>) {
        bookings = newList
        notifyDataSetChanged()
    }

    private fun showReceiptDialog(context: android.content.Context, booking: Booking, title: String) {
        val dialog = Dialog(context)
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE)
        dialog.setCancelable(true)
        dialog.setContentView(R.layout.activity_payment) // Re-use payment receipt overlay xml
        
        dialog.window?.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
        dialog.window?.setLayout(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)

        // Show the Success state layout and hide others inside the dialog
        val formScroll = dialog.findViewById<ViewGroup>(R.id.paymentFormScrollView)
        val loaderLayout = dialog.findViewById<ViewGroup>(R.id.paymentLoadingLayout)
        val successLayout = dialog.findViewById<ViewGroup>(R.id.paymentSuccessLayout)

        formScroll?.visibility = android.view.View.GONE
        loaderLayout?.visibility = android.view.View.GONE
        successLayout?.visibility = android.view.View.VISIBLE

        // Populate receipt detail text
        dialog.findViewById<TextView>(R.id.tvReceiptRef)?.text = booking.referenceNumber
        dialog.findViewById<TextView>(R.id.tvReceiptAmount)?.text = "BWP ${String.format("%,.2f", booking.depositPaid)}"
        dialog.findViewById<TextView>(R.id.tvReceiptRoom)?.text = title

        // Set action button behavior
        val doneBtn = dialog.findViewById<Button>(R.id.btnReceiptDone)
        doneBtn?.text = "Print / Download Receipt"
        doneBtn?.setOnClickListener {
            Toast.makeText(context, "Receipt PDF printed successfully!", Toast.LENGTH_SHORT).show()
            dialog.dismiss()
        }

        dialog.show()
    }
}
