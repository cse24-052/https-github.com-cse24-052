package com.uninest.app.models

data class Student(
    val id: Int = 0,
    val username: String,
    val name: String,
    val role: String = "Student", // "Student" or "Provider"
    val email: String,
    val phone: String = "+267 71234567"
)

data class Listing(
    val id: Int = 0,
    val title: String,
    val price: Double,
    val location: String,
    val type: String, // "Single Room", "Bedsitter", "Shared Apartment", "1-Bedroom Flat", "Cottage", etc.
    val amenities: String, // Comma-separated list
    val availabilityDate: String, // "yyyy-MM-dd" or "dd MMM yyyy"
    val depositAmount: Double,
    val imageUrl: String,
    val status: String = "Available", // "Available" or "Reserved"
    val distanceBAC: Double = 0.0, // Distance to BAC campus in km
    val distanceUB: Double = 0.0,  // Distance to UB campus in km
    val distanceBotho: Double = 0.0, // Distance to Botho campus in km
    val providerId: Int = 0
)

data class Booking(
    val id: Int = 0,
    val studentId: Int,
    val listingId: Int,
    val referenceNumber: String,
    val depositPaid: Double,
    val bookingDate: String
)

data class SearchPreference(
    val id: Int = 0,
    val studentId: Int,
    val maxPrice: Double,
    val location: String,
    val availabilityDate: String
)

data class SmartAlert(
    val id: Int = 0,
    val studentId: Int,
    val listingId: Int,
    val message: String,
    val isRead: Int = 0, // 0 = unread, 1 = read
    val createdAt: String
)
