package com.uninest.app.fragments

import android.content.Intent
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.Toast
import androidx.fragment.app.Fragment
import com.uninest.app.LoginActivity
import com.uninest.app.MainActivity
import com.uninest.app.database.UniNestDbHelper
import com.uninest.app.databinding.FragmentProfileBinding
import com.uninest.app.models.Student

class ProfileFragment : Fragment() {

    private var _binding: FragmentProfileBinding? = null
    private val binding get() = _binding!!

    private lateinit var dbHelper: UniNestDbHelper
    private var studentsList = ArrayList<Student>()
    private var isSpinnerInitializing = true

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentProfileBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        dbHelper = UniNestDbHelper(requireContext())
        studentsList.addAll(dbHelper.getAllStudents())

        displayProfileInfo()
        setupRoleSwitch()
        setupStudentSwitcher()
        setupLogout()
    }

    private fun displayProfileInfo() {
        val activity = activity as? MainActivity ?: return
        val currentUsername = activity.studentUsername
        val currentStudent = dbHelper.getStudentByUsername(currentUsername)

        if (currentStudent != null) {
            binding.tvProfileName.text = currentStudent.name
            binding.tvProfileRole.text = "Role: ${currentStudent.role}"
            binding.tvProfileEmail.text = currentStudent.email
            binding.tvProfilePhone.text = currentStudent.phone
        } else {
            binding.tvProfileName.text = activity.studentName
            binding.tvProfileRole.text = "Role: Student"
            binding.tvProfileEmail.text = "${activity.studentUsername}@student.ac.bw"
            binding.tvProfilePhone.text = "+267 76543210"
        }
    }

    private fun setupRoleSwitch() {
        // Handle visual state check for Provider switch
        binding.switchRole.setOnCheckedChangeListener { _, isChecked ->
            val newRole = if (isChecked) "Provider" else "Student"
            binding.tvProfileRole.text = "Role: $newRole"
            Toast.makeText(context, "Switched view to $newRole mode!", Toast.LENGTH_SHORT).show()
        }
    }

    private fun setupStudentSwitcher() {
        val displayNames = ArrayList<String>()
        var activeSelectionIndex = 0
        val activity = activity as? MainActivity ?: return
        val currentId = activity.studentId

        for (i in studentsList.indices) {
            val student = studentsList[i]
            displayNames.add("${student.name} (${student.username})")
            if (student.id == currentId) {
                activeSelectionIndex = i
            }
        }

        val spinnerAdapter = ArrayAdapter(requireContext(), android.R.layout.simple_spinner_item, displayNames)
        spinnerAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        binding.spinnerProfileStudentSwitch.adapter = spinnerAdapter
        
        // Pre-select current student
        binding.spinnerProfileStudentSwitch.setSelection(activeSelectionIndex)

        binding.spinnerProfileStudentSwitch.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) {
                // Skip the initial callback during setup to prevent loops
                if (isSpinnerInitializing) {
                    isSpinnerInitializing = false
                    return
                }
                
                val selectedStudent = studentsList[position]
                if (selectedStudent.id != activity.studentId) {
                    Toast.makeText(context, "Switching student to ${selectedStudent.name}", Toast.LENGTH_SHORT).show()
                    activity.switchLoggedStudent(selectedStudent.id, selectedStudent.username, selectedStudent.name)
                }
            }

            override fun onNothingSelected(parent: AdapterView<*>?) {}
        }
    }

    private fun setupLogout() {
        binding.btnLogout.setOnClickListener {
            Toast.makeText(context, "Signing out...", Toast.LENGTH_SHORT).show()
            val intent = Intent(requireActivity(), LoginActivity::class.java).apply {
                flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
            }
            startActivity(intent)
            requireActivity().finish()
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
