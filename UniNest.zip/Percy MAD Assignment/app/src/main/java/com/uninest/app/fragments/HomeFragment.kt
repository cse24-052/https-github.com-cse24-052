package com.uninest.app.fragments

import android.app.AlertDialog
import android.content.Intent
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.Spinner
import android.widget.Toast
import androidx.core.content.ContextCompat
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.LinearLayoutManager
import com.uninest.app.ListingDetailActivity
import com.uninest.app.MainActivity
import com.uninest.app.R
import com.uninest.app.adapters.FeaturedAdapter
import com.uninest.app.adapters.ListingAdapter
import com.uninest.app.database.UniNestDbHelper
import com.uninest.app.databinding.FragmentHomeBinding
import com.uninest.app.models.Listing

class HomeFragment : Fragment() {

    private var _binding: FragmentHomeBinding? = null
    private val binding get() = _binding!!

    private lateinit var dbHelper: UniNestDbHelper
    private lateinit var featuredAdapter: FeaturedAdapter
    private lateinit var recommendedAdapter: ListingAdapter

    // Active filters
    private var searchQuery: String? = null
    private var filterMaxPrice: Double? = null
    private var filterLocation: String? = null
    private var filterDate: String? = null

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentHomeBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        dbHelper = UniNestDbHelper(requireContext())

        setupGreetings()
        setupSearch()
        setupFilterChips()
        setupRecyclers()
        loadDefaultListings()

        // Notification Bell click triggers simulated alert check or navigates to Alerts tab
        binding.btnNotification.setOnClickListener {
            val mainAct = activity as? MainActivity
            mainAct?.navigateToExplore(0) // or navigate to Alerts tab
            Toast.makeText(context, "Navigating to Alerts to check preferences!", Toast.LENGTH_SHORT).show()
        }
        
        // Hide/show red badge dot if there are unread alerts
        checkAlertBadge()
    }

    private fun setupGreetings() {
        val mainAct = activity as? MainActivity
        val studentName = mainAct?.studentName ?: "Ookeditse"
        val firstName = studentName.split(" ").firstOrNull() ?: "Ookeditse"
        binding.tvWelcomeSub.text = "$firstName, find your perfect student home in Gaborone."
    }

    private fun setupSearch() {
        binding.etSearch.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                searchQuery = if (s.isNullOrBlank()) null else s.toString().trim()
                applyFilters()
            }
            override fun afterTextChanged(s: Editable?) {}
        })
    }

    private fun setupFilterChips() {
        binding.chipPrice.setOnClickListener { showPriceFilterDialog() }
        binding.chipLocation.setOnClickListener { showLocationFilterDialog() }
        binding.chipAvailability.setOnClickListener { showDateFilterDialog() }
    }

    private fun setupRecyclers() {
        // Featured Horizontal Recycler
        featuredAdapter = FeaturedAdapter(ArrayList()) { listing ->
            openListingDetail(listing.id)
        }
        binding.rvFeatured.layoutManager = LinearLayoutManager(context, LinearLayoutManager.HORIZONTAL, false)
        binding.rvFeatured.adapter = featuredAdapter

        // Recommended Vertical Recycler
        recommendedAdapter = ListingAdapter(ArrayList()) { listing ->
            openListingDetail(listing.id)
        }
        binding.rvRecommended.layoutManager = LinearLayoutManager(context, LinearLayoutManager.VERTICAL, false)
        binding.rvRecommended.adapter = recommendedAdapter
    }

    private fun loadDefaultListings() {
        val all = dbHelper.getAllListings()
        // Splitting: even indexes are featured, odd indexes are recommended
        val featured = all.filterIndexed { index, _ -> index % 2 == 0 }
        val recommended = all.filterIndexed { index, _ -> index % 2 != 0 }

        featuredAdapter.updateData(featured.take(15))
        recommendedAdapter.updateData(recommended.take(15))
    }

    private fun applyFilters() {
        val filtered = dbHelper.searchListings(searchQuery, filterMaxPrice, filterLocation, filterDate)
        
        // Split filtered list
        val featured = filtered.filterIndexed { index, _ -> index % 2 == 0 }
        val recommended = filtered.filterIndexed { index, _ -> index % 2 != 0 }

        featuredAdapter.updateData(featured)
        recommendedAdapter.updateData(recommended)

        // Show empty message if nothing matches
        if (filtered.isEmpty()) {
            Toast.makeText(context, "No accommodations match your search.", Toast.LENGTH_SHORT).show()
        }
    }

    private fun showPriceFilterDialog() {
        val prices = arrayOf("Any", "Under BWP 1,200", "Under BWP 1,800", "Under BWP 2,500", "Under BWP 3,500")
        val builder = AlertDialog.Builder(requireContext(), android.R.style.Theme_DeviceDefault_Light_Dialog)
        builder.setTitle("Select Maximum Budget")
        builder.setItems(prices) { _, which ->
            when (which) {
                0 -> {
                    filterMaxPrice = null
                    updateChipState(binding.chipPrice, "Price", false)
                }
                1 -> {
                    filterMaxPrice = 1200.0
                    updateChipState(binding.chipPrice, "Max BWP 1.2K", true)
                }
                2 -> {
                    filterMaxPrice = 1800.0
                    updateChipState(binding.chipPrice, "Max BWP 1.8K", true)
                }
                3 -> {
                    filterMaxPrice = 2500.0
                    updateChipState(binding.chipPrice, "Max BWP 2.5K", true)
                }
                4 -> {
                    filterMaxPrice = 3500.0
                    updateChipState(binding.chipPrice, "Max BWP 3.5K", true)
                }
            }
            applyFilters()
        }
        builder.show()
    }

    private fun showLocationFilterDialog() {
        val locations = arrayOf("All", "Block 7", "Block 9", "Phase 2", "Broadhurst", "Tlokweng", "Gaborone West", "Phakalane", "Tsholofelo", "Village")
        val builder = AlertDialog.Builder(requireContext(), android.R.style.Theme_DeviceDefault_Light_Dialog)
        builder.setTitle("Select Gaborone Area")
        builder.setItems(locations) { _, which ->
            if (which == 0) {
                filterLocation = null
                updateChipState(binding.chipLocation, "Location", false)
            } else {
                filterLocation = locations[which]
                updateChipState(binding.chipLocation, locations[which], true)
            }
            applyFilters()
        }
        builder.show()
    }

    private fun showDateFilterDialog() {
        val dates = arrayOf("Any", "01 Jun 2026", "15 Jun 2026", "01 Jul 2026", "15 Jul 2026", "01 Aug 2026", "15 Aug 2026")
        val builder = AlertDialog.Builder(requireContext(), android.R.style.Theme_DeviceDefault_Light_Dialog)
        builder.setTitle("Select Availability Date")
        builder.setItems(dates) { _, which ->
            if (which == 0) {
                filterDate = null
                updateChipState(binding.chipAvailability, "Availability Date", false)
            } else {
                filterDate = dates[which]
                updateChipState(binding.chipAvailability, dates[which], true)
            }
            applyFilters()
        }
        builder.show()
    }

    private fun updateChipState(chip: Button, text: String, isActive: Boolean) {
        chip.text = text
        if (isActive) {
            chip.setBackgroundResource(R.drawable.bg_chip_selected)
            chip.setTextColor(ContextCompat.getColor(requireContext(), R.color.text_on_primary))
        } else {
            chip.setBackgroundResource(R.drawable.bg_chip_unselected)
            chip.setTextColor(ContextCompat.getColor(requireContext(), R.color.text_primary))
        }
    }

    private fun openListingDetail(listingId: Int) {
        val intent = Intent(context, ListingDetailActivity::class.java).apply {
            putExtra("listing_id", listingId)
            val mainAct = activity as? MainActivity
            putExtra("student_id", mainAct?.studentId ?: 0)
        }
        startActivity(intent)
    }

    private fun checkAlertBadge() {
        val mainAct = activity as? MainActivity
        if (mainAct != null) {
            val unread = dbHelper.getStudentAlerts(mainAct.studentId).any { it.isRead == 0 }
            binding.viewNotificationBadge.visibility = if (unread) View.VISIBLE else View.GONE
        }
    }

    override fun onResume() {
        super.onResume()
        checkAlertBadge()
        // Refresh listings on screen resume to capture status updates (e.g. reserved status)
        if (searchQuery != null || filterMaxPrice != null || filterLocation != null || filterDate != null) {
            applyFilters()
        } else {
            loadDefaultListings()
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
