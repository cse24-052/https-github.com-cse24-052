package com.uninest.app.fragments

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.LinearLayoutManager
import com.uninest.app.MainActivity
import com.uninest.app.adapters.BookingAdapter
import com.uninest.app.database.UniNestDbHelper
import com.uninest.app.databinding.FragmentBookingsBinding

class BookingsFragment : Fragment() {

    private var _binding: FragmentBookingsBinding? = null
    private val binding get() = _binding!!

    private lateinit var dbHelper: UniNestDbHelper
    private lateinit var adapter: BookingAdapter

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentBookingsBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        dbHelper = UniNestDbHelper(requireContext())

        setupRecyclerView()
        loadBookings()
    }

    private fun setupRecyclerView() {
        binding.rvBookings.layoutManager = LinearLayoutManager(context)
        // Pass empty list initially, update in loadBookings()
        adapter = BookingAdapter(ArrayList(), dbHelper)
        binding.rvBookings.adapter = adapter
    }

    private fun loadBookings() {
        val activity = activity as? MainActivity
        val studentId = activity?.studentId ?: 0
        val studentName = activity?.studentName ?: "Student"

        val bookings = dbHelper.getStudentBookings(studentId)

        if (bookings.isEmpty()) {
            binding.emptyStateLayout.visibility = View.VISIBLE
            binding.rvBookings.visibility = View.GONE
            binding.tvBookingsSubtitle.text = "No bookings found for $studentName"
        } else {
            binding.emptyStateLayout.visibility = View.GONE
            binding.rvBookings.visibility = View.VISIBLE
            binding.tvBookingsSubtitle.text = "Showing ${bookings.size} reserved rooms for $studentName"
            adapter.updateData(bookings)
        }
    }

    override fun onResume() {
        super.onResume()
        loadBookings()
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
